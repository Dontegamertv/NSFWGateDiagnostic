
# NSFW Gate Diagnostic

Version: 1.0.0

A diagnostic-only Unbound plugin.

## Features

- Plugin startup logging
- Plugin shutdown logging
- Basic self-test
- No Discord age-gate modifications
- No changes to account permissions

## Development

Requires the Unbound development toolchain.

